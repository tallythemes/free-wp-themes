<?php
/*
Template Name: Front Page
*/
tally_layout();