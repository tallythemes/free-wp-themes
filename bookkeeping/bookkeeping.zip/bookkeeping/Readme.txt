== Tally Framework ==
Bookkeeping WordPress Theme is perfect for bookkeeping, accounting website. Also It can be use for any type of website. The theme is responsive  that looks great on any device.  This is a child theme of Tally Framework theme and the option panel is powered by Option Tree plugin. It also support TallyKit plugin that will supply lot of functionality.


== Theme License & Copyright ==
Bookkeeping WordPress theme, Copyright (C) 2014 TallyThemes
Bookkeeping WordPress theme is licensed under the GPL.


== License == 
This theme, like WordPress, is licensed under the GPL 2.0.


Images -
images that show in the theme are created by Us.